package sa1;
import java.util.ArrayList;
import java.util.List;
//Kai Engwall. I pledge My Honor I have abided by the Stevens Honor System. X Kai Engwall
public class ListCollection<E> {
  private int nodeCount;
  protected List<SingleLL<E>> collection;

  /**
   * Base constructor, initializes an empty ListCollection.
   */
  public ListCollection() {
	  nodeCount = 0;
	  collection = new ArrayList<SingleLL<E>>();
  }

  /**
   * Initializes a ListCollection with `numLists` lists.
   * 
   * @param numLists
   */
  public ListCollection(int numLists) {
	  if(numLists<=0) {
		  throw new IllegalArgumentException("Rows must be greater than zero");
	  }
	  collection = new ArrayList<SingleLL<E>>();
	  for(int i = 0; i < numLists; i++) {
		  collection.add(new SingleLL<E>());
	  }
	  nodeCount = 0;
  }

  /**
   * @return The size of the `ListCollection`
   */
  public int size() {
	  return collection.size();
  }

  /**
   * Sets the nodeCount
   * 
   * @param nodeCount
   */
  public void setNodeCount(int nodeCount) {
	  this.nodeCount = nodeCount;
  }

  /**
   * @return the nodeCount
   */
  public int getNodeCount() {
	  return nodeCount;
  }

  /**
   * Adds the specified `SingleLL` to the end of the `ListCollection`
   * 
   * @param list
   */
  public void addList(SingleLL<E> list) {
	  collection.add(list);
	  nodeCount+=list.size();
  }

  /**
   * Adds the specified `List` to the `ListCollection`
   * 
   * @param list
   * @complexity Your big-o and supporting explanation here
   * The big-o time complexity of this method is O(n), where n is the size of the list  Because you have to loop through the size of the list, this is O(n) complexity.
   * The add() method is instantaneous or O(1) when adding to the end of the list, thus it would be O(n + 1) overall or just O(n).
   */
  public void addList(List<E> list) {
	  SingleLL<E> l = new SingleLL<>();
	  for(E item: list) {
		  l.append(item);
	  }
	  nodeCount+=l.size();
	  collection.add(l);
  }

  /**
   * Returns the list at the specified index
   * 
   * @throws IllegalArgumentException when index out of bounds
   * @param listIndex
   * @return the list
   */
  public SingleLL<E> getList(int listIndex) {
	  if(listIndex > this.size() -1 || listIndex <0){
		  throw new IllegalArgumentException("Index is out of bounds.");
	  }
	  return collection.get(listIndex);
  }

  /**
   * Adds an element to the `elemIndex` position of the list at `listIndex`
   * 
   * @throws IllegalArgumentException when index out of bounds
   * @param listIndex
   * @param elemIndex
   * @param elem
   * @complexity Your big-o and supporting explanation here
   * The time complexity is O(n), where n is the size of the list that is being added to. Because get is an instantaneous time complexity method, it won't add to the complexity
   * of looping through the SingleLL you are adding to. Worst case scenario, you loop through to the last index in the SingleLL, so this would be linear time complexity.
   * 
   */
  public void addElem(int listIndex, int elemIndex, E elem) {
	  if(listIndex > this.size() -1 || listIndex < 0){
		  throw new IllegalArgumentException("Index is out of bounds.");
	  }
	  collection.get(listIndex).insert(elemIndex,elem);
	  nodeCount++;
  }

  /**
   * Sets the element at the `elemIndex` position of the list at `listIndex`
   * 
   * @throws IllegalArgumentException when index out of bounds
   * @param listIndex
   * @param elemIndex
   * @param elem
   */
  public void setElem(int listIndex, int elemIndex, E elem) {
	  if(listIndex > this.size() -1 || listIndex < 0){
		  throw new IllegalArgumentException("Index is out of bounds.");
	  }
	  collection.get(listIndex).set(elemIndex, elem);
  }

  /**
   * Returns the element at the `elemIndex` position of the list at `listIndex`
   * 
   * @throws IllegalArgumentException when index out of bounds
   * @param listIndex
   * @param elemIndex
   * @return
   */
  public E getElem(int listIndex, int elemIndex) {
	  if(listIndex > this.size() -1 || listIndex < 0){
		  throw new IllegalArgumentException("Index is out of bounds.");
	  }
	  return collection.get(listIndex).get(elemIndex);
  }

  /**
   * Returns the `ListCollection` in string form, following STRICTLY the rule of
   * "[LIST1, LIST2, LIST3, ... ]" Ex: [[0, 1, 2], [3, 4, 5] [6, 7, 8]]
   */
  public String toString() {
	  if(this.size() == 0) {
		  return "[]";
	  }
	  StringBuilder s = new StringBuilder();
	  s.append("[");
	  for(int i = 0; i < this.size()-1;i++) {
		  s.append(collection.get(i).toString() + ", ");
	  }
	  s.append(collection.get(collection.size()-1).toString());
	  s.append("]");
	  return s.toString();
  }

  
//  public static void main(String[] args) {
//	  ListCollection<Integer> l = new ListCollection<>();
//	  SingleLL<Integer> sl = new SingleLL<Integer>();
//	  sl.append(0);
//	  sl.append(1);
//	  sl.append(2);
//	  sl.append(3);
//	  List intList = new ArrayList();
//	  intList.add(1);
//	  intList.add(2);
//	  intList.add(3);
//	  intList.add(4);
//	 
//	  l.addList(intList);
//	  l.addList(sl);
//	  l.addElem(1, 3, 100);
//	  l.setElem(0, 3, -100);
//	  System.out.println(l);
//	  System.out.println(l.getList(1));
//	  System.out.println(l.getNodeCount());
//	  System.out.println(l.getElem(1, 2));
//	  
//	  
//	  ListCollection<Integer> testCollection = new ListCollection<>();
//		SingleLL<Integer> testList1 = new SingleLL<>();
//		SingleLL<Integer> testList2 = new SingleLL<>();
//		List<Integer> testList3 = new ArrayList<>();
//		for (int i = 1; i < 11; i++)
//			testList1.append(i);
//		for (int i = 11; i < 21; i++)
//			testList2.append(i);
//		for (int i = 21; i < 31; i++)
//			testList3.add(i);
//		testCollection.addList(testList1);
//		testCollection.addList(testList2);
//		System.out.println(testCollection.toString());
//  }
}
