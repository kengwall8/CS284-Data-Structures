package sa1;
public class ListMatrix extends ListCollection<Integer> {
  private int rows;
  private int columns;
//Kai Engwall. I pledge My Honor I have abided by the Stevens Honor System. X Kai Engwall
  /**
   * Initializes a `ListMatrix` with the specified number of rows and columns. By
   * default, ALL elements are set to 0.
   * 
   * @param rows
   * @param columns
   */
  public ListMatrix(int rows, int columns) {
	  super(rows);
	  if(rows <= 0 || columns <= 0) {
		  throw new IllegalArgumentException("Rows and columns must be greater than zero.");
	  }
	  
	  this.rows = rows;
	  this.columns = columns;
	  for(int r = 0; r < rows; r++) {
		  for(int c = 0; c < columns; c++) {
			  collection.get(r).append(0);
			  this.setNodeCount(this.getNodeCount()+1);
		  }
	  }
  }

  /**
   * @return the number of rows
   */
  public int numRows() {
    return this.rows;
  }

  /**
   * 
   * @return the number of columns
   */
  public int numColumns() {
    return this.columns;
  }

  /**
   * Adds the `ListMatrix` to `ListMatrix other`, storing the result in the caller
   * (this)
   * 
   * @throws IllegalArgumentException if dimensions do not properly coincide
   * @param other
   * @complexity Your big-o and supporting explanation here
   * The time complexity is O(n*m^2) where n is the number of rows and m is the number of columns.
   * Because the first loop is O(n) complexity, as it loops through the number of rows, and the second loop is nested inside of the first loop with a complexity
   * of O(m) (it loops through the number of columns),Then the line setElem(r, c, this.getElem(r, c) + other.getElem(r, c)) has a complexity of 3m or simply m, because
   * setElem and getElem have complexities of O(m). Thus the line inside the innermost loop will run m times, making the total complexity for the inner loop O(m^2).
   * Next the outermost loop has a complexity of O(n), and because the inner loop runs n times, the total complexity will be O(n*m^2)
   */
  public void add(ListMatrix other) {
	  if(this.numColumns() != other.numColumns() || this.numRows()!= other.numRows()) {
		  throw new IllegalArgumentException("Rows and columns of the two matrices do not match!");
	  }
	  for(int r = 0; r < this.numRows(); r++) {
		  for(int c = 0; c < this.numColumns(); c++) {
			  setElem(r, c, this.getElem(r, c) + other.getElem(r, c));
		  }
	  }
  }

  /**
   * Returns the transpose of the matrix
   * 
   * @param matrix
   * @return matrix transpose
   */
  public static ListMatrix transpose(ListMatrix matrix) {
	  ListMatrix LMT = new ListMatrix(matrix.numColumns(),matrix.numRows());
	  for(int r = 0; r < matrix.numRows(); r++) {
		  for(int c = 0; c < matrix.numColumns(); c++) {
			  LMT.setElem(c, r, matrix.getElem(r, c));
		  }
	  }
	  return LMT;
  }

  /**
   * Multiplies the `ListMatrix` with `ListMatrix other`, returning the result as
   * a new `ListMatrix.
   * 
   * @throws IllegalArgumentException if dimensions do not peoperly coincide
   * @param other
   * @return
   */
  public ListMatrix multiply(ListMatrix other) {
	  if(this.numColumns() != other.numRows()) {
		  throw new IllegalArgumentException("Rows and columns of the two matrices do not match!");
	  }
	  int tracker = 0;
	  ListMatrix LMM = new ListMatrix(other.numColumns(),other.numColumns());
	  
	  for(int LMMr = 0; LMMr < this.numRows(); LMMr++) {
		  for(int r = 0; r < other.numColumns(); r++) {
			  tracker = 0;
			  for(int c = 0; c < other.numRows(); c++) {
				  tracker += this.getElem(LMMr, c) * other.getElem(c, r);
				  	
			  }
			  LMM.setElem(LMMr, r, tracker);
		  }
		  
		  
	  }
	  return LMM;
  }

//public static void main(String[] args) {
//	  ListMatrix test = new ListMatrix(3,4);
//	  System.out.println(test);
//	  System.out.println(test.numColumns() + " columns");
//	  System.out.println(test.numRows() + " rows");
//	  test.setElem(1, 0, 1);
//	  test.setElem(1, 1, 2);
//	  test.setElem(1, 2, 3);
//	  test.setElem(1, 3, 4);
//	  test.setElem(0, 0, 1);
//	  test.setElem(0, 1, 2);
//	  test.setElem(0, 2, 3);
//	  test.setElem(0, 3, 4);
//	  System.out.println(test);
	  
//	  ListMatrix test2 = new ListMatrix(3,4);
//	  test2.setElem(1, 0, 1);
//	  test2.setElem(1, 1, 2);
//	  test2.setElem(1, 2, 3);
//	  test2.setElem(1, 3, 4);
//	  test2.setElem(2, 0, 1);
//	  test2.setElem(2, 1, 2);
//	  test2.setElem(2, 2, 3);
//	  test2.setElem(2, 3, 4);
//	  System.out.println(test2);
//	  test.add(test2);
//	  System.out.println(test);
//	  ListMatrix test3 = new ListMatrix(2,3);
//	  test3.setElem(0, 0, 1);
//	  test3.setElem(0, 1, 2);
//	  test3.setElem(0, 2, 3);
//	  test3.setElem(1, 0, 4);
//	  test3.setElem(1, 1, 5);
//	  test3.setElem(1, 2, 6);
//	  ListMatrix test4 = new ListMatrix(3,2);
//	  test4.setElem(0, 0, 6);
//	  test4.setElem(0, 1, 3);
//	  test4.setElem(1, 0, 5);
//	  test4.setElem(1, 1, 2);
//	  test4.setElem(2, 0, 4);
//	  test4.setElem(2, 1, 1);
//	  System.out.println(test3);
//	  System.out.println(test4);
//	  System.out.println(test3.multiply(test4));
//	  
//	  
//	
//	ListMatrix test1 = new ListMatrix(11,2);
//	System.out.println(test1.getNodeCount());
//	}
  
}
